<?php 
// DB credentials.
define('DB_HOST','sql205.ezyro.com');
define('DB_USER','ezyro_27070557');
define('DB_PASS','And@0507');
define('DB_NAME','ezyro_27070557_library');
// Establish database connection.
try
{
$dbh = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME,DB_USER, DB_PASS,array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
}
catch (PDOException $e)
{
exit("Error: " . $e->getMessage());
}
?>